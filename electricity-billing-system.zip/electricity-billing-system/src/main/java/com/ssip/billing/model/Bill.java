package com.ssip.billing.model;

import java.time.LocalDate;

public class Bill {
    private String meterNumber;
    private int unitsConsumed;
    private String billingMonth;
    private double amountDue;
    private boolean isPaid;
    private LocalDate dueDate;
    private LocalDate paymentDate;
    private static final double RATE_PER_UNIT = 7.50;
    
    public Bill() {}
    
    public Bill(String meterNumber, int unitsConsumed, String billingMonth) {
        this.meterNumber = meterNumber;
        this.unitsConsumed = unitsConsumed;
        this.billingMonth = billingMonth;
        this.amountDue = calculateAmount(unitsConsumed);
        this.isPaid = false;
        this.dueDate = LocalDate.now().plusDays(30);
        this.paymentDate = null;
    }
    
    private double calculateAmount(int units) {
        return units * RATE_PER_UNIT;
    }
    
    // Getters and Setters
    public String getMeterNumber() { return meterNumber; }
    public void setMeterNumber(String meterNumber) { this.meterNumber = meterNumber; }
    
    public int getUnitsConsumed() { return unitsConsumed; }
    public void setUnitsConsumed(int unitsConsumed) { 
        this.unitsConsumed = unitsConsumed;
        this.amountDue = calculateAmount(unitsConsumed);
    }
    
    public String getBillingMonth() { return billingMonth; }
    public void setBillingMonth(String billingMonth) { this.billingMonth = billingMonth; }
    
    public double getAmountDue() { return amountDue; }
    public void setAmountDue(double amountDue) { this.amountDue = amountDue; }
    
    public boolean isPaid() { return isPaid; }
    public void setPaid(boolean paid) { 
        this.isPaid = paid;
        if (paid && this.paymentDate == null) {
            this.paymentDate = LocalDate.now();
        }
    }
    
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    
    public static double getRatePerUnit() { return RATE_PER_UNIT; }
}