package com.ssip.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricityBillingApplication {
    public static void main(String[] args) {
        SpringApplication.run(ElectricityBillingApplication.class, args);
    }
}