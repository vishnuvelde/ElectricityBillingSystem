package com.ssip.billing.service;

import com.ssip.billing.model.Bill;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BillingService {
    private final Map<String, List<Bill>> billStorage = new HashMap<>();
    
    public BillingService() {
        // Initialize with sample data
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        // Sample bills for testing
        generateBill("MTR001", 150, "January 2025");
        generateBill("MTR001", 180, "February 2025");
        generateBill("MTR002", 120, "January 2025");
        generateBill("MTR002", 200, "February 2025");
        generateBill("MTR003", 90, "January 2025");
        
        // Mark some bills as paid for demo
        payBill("MTR001", "January 2025");
        payBill("MTR002", "January 2025");
    }
    
    public Bill generateBill(String meterNumber, int unitsConsumed, String billingMonth) {
        Bill bill = new Bill(meterNumber, unitsConsumed, billingMonth);
        
        billStorage.computeIfAbsent(meterNumber, k -> new ArrayList<>()).add(bill);
        
        return bill;
    }
    
    public List<Bill> getBillsByMeterNumber(String meterNumber) {
        return billStorage.getOrDefault(meterNumber, new ArrayList<>());
    }
    
    public List<Bill> getUnpaidBills(String meterNumber) {
        return getBillsByMeterNumber(meterNumber).stream()
                .filter(bill -> !bill.isPaid())
                .collect(Collectors.toList());
    }
    
    public List<Bill> getPaidBills(String meterNumber) {
        return getBillsByMeterNumber(meterNumber).stream()
                .filter(Bill::isPaid)
                .collect(Collectors.toList());
    }
    
    public boolean payBill(String meterNumber, String billingMonth) {
        List<Bill> bills = getBillsByMeterNumber(meterNumber);
        
        for (Bill bill : bills) {
            if (bill.getBillingMonth().equals(billingMonth) && !bill.isPaid()) {
                bill.setPaid(true);
                return true;
            }
        }
        return false;
    }
    
    public Bill getBill(String meterNumber, String billingMonth) {
        return getBillsByMeterNumber(meterNumber).stream()
                .filter(bill -> bill.getBillingMonth().equals(billingMonth))
                .findFirst()
                .orElse(null);
    }
    
    public List<String> getAllMeterNumbers() {
        return new ArrayList<>(billStorage.keySet());
    }
    
    public double getTotalAmountDue(String meterNumber) {
        return getUnpaidBills(meterNumber).stream()
                .mapToDouble(Bill::getAmountDue)
                .sum();
    }
}