package com.ssip.billing.controller;

import com.ssip.billing.model.Bill;
import com.ssip.billing.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bills")
@CrossOrigin(origins = "*")
public class BillingController {
    
    @Autowired
    private BillingService billingService;
    
    @PostMapping("/generate")
    public ResponseEntity<Bill> generateBill(@RequestBody Map<String, Object> request) {
        try {
            String meterNumber = (String) request.get("meterNumber");
            int unitsConsumed = Integer.parseInt(request.get("unitsConsumed").toString());
            String billingMonth = (String) request.get("billingMonth");
            
            Bill bill = billingService.generateBill(meterNumber, unitsConsumed, billingMonth);
            return ResponseEntity.ok(bill);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @GetMapping("/{meterNumber}")
    public ResponseEntity<List<Bill>> getBills(@PathVariable String meterNumber) {
        List<Bill> bills = billingService.getBillsByMeterNumber(meterNumber);
        if (bills.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(bills);
    }
    
    @GetMapping("/{meterNumber}/unpaid")
    public ResponseEntity<List<Bill>> getUnpaidBills(@PathVariable String meterNumber) {
        List<Bill> unpaidBills = billingService.getUnpaidBills(meterNumber);
        return ResponseEntity.ok(unpaidBills);
    }
    
    @GetMapping("/{meterNumber}/paid")
    public ResponseEntity<List<Bill>> getPaidBills(@PathVariable String meterNumber) {
        List<Bill> paidBills = billingService.getPaidBills(meterNumber);
        return ResponseEntity.ok(paidBills);
    }
    
    @PutMapping("/{meterNumber}/pay")
    public ResponseEntity<String> payBill(@PathVariable String meterNumber, 
                                        @RequestBody Map<String, String> request) {
        String billingMonth = request.get("billingMonth");
        
        boolean success = billingService.payBill(meterNumber, billingMonth);
        if (success) {
            return ResponseEntity.ok("Payment successful");
        } else {
            return ResponseEntity.badRequest().body("Bill not found or already paid");
        }
    }
    
    @GetMapping("/{meterNumber}/total-due")
    public ResponseEntity<Map<String, Double>> getTotalDue(@PathVariable String meterNumber) {
        double totalDue = billingService.getTotalAmountDue(meterNumber);
        return ResponseEntity.ok(Map.of("totalAmountDue", totalDue));
    }
    
    @GetMapping("/meters")
    public ResponseEntity<List<String>> getAllMeterNumbers() {
        List<String> meterNumbers = billingService.getAllMeterNumbers();
        return ResponseEntity.ok(meterNumbers);
    }
}