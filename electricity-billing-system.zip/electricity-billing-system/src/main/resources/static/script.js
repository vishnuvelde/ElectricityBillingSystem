const API_BASE_URL = '/api/bills';

let currentMeterNumber = '';
let currentBillType = 'all';

// Navigation functions
function showSection(sectionName) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.getElementById(sectionName + '-section').classList.add('active');
    event.target.classList.add('active');
}

// Customer Portal Functions
async function getBills() {
    const meterNumber = document.getElementById('meterNumber').value.trim();
    
    if (!meterNumber) {
        showMessage('Please enter a meter number', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/${meterNumber}`);
        
        if (response.ok) {
            const bills = await response.json();
            currentMeterNumber = meterNumber;
            displayBills(bills, 'all');
            updateTotalDue();
            document.getElementById('bills-display').style.display = 'block';
            showMessage('Bills loaded successfully', 'success');
        } else if (response.status === 404) {
            showMessage('No bills found for this meter number', 'error');
            document.getElementById('bills-display').style.display = 'none';
        } else {
            throw new Error('Failed to fetch bills');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error loading bills. Please try again.', 'error');
    }
}

async function showBills(type) {
    if (!currentMeterNumber) return;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    currentBillType = type;
    
    try {
        let url = `${API_BASE_URL}/${currentMeterNumber}`;
        if (type === 'unpaid') {
            url += '/unpaid';
        } else if (type === 'paid') {
            url += '/paid';
        }
        
        const response = await fetch(url);
        const bills = await response.json();
        
        displayBills(bills, type);
        
        if (type === 'unpaid') {
            updateTotalDue();
        } else {
            document.getElementById('total-due').style.display = 'none';
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error loading bills', 'error');
    }
}

function displayBills(bills, type) {
    const container = document.getElementById('bills-container');
    
    if (bills.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <h3>No ${type === 'all' ? '' : type} bills found</h3>
                <p>There are no ${type === 'all' ? '' : type} bills for this meter number.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = bills.map(bill => `
        <div class="bill-item">
            <div class="bill-header">
                <div class="bill-month">${bill.billingMonth}</div>
                <div class="bill-status ${bill.paid ? 'status-paid' : 'status-unpaid'}">
                    ${bill.paid ? 'PAID' : 'UNPAID'}
                </div>
            </div>
            <div class="bill-details">
                <div class="bill-detail">
                    <span class="detail-label">Meter Number:</span>
                    <span class="detail-value">${bill.meterNumber}</span>
                </div>
                <div class="bill-detail">
                    <span class="detail-label">Units Consumed:</span>
                    <span class="detail-value">${bill.unitsConsumed} kWh</span>
                </div>
                <div class="bill-detail">
                    <span class="detail-label">Rate per Unit:</span>
                    <span class="detail-value">₹${bill.ratePerUnit || 7.50}</span>
                </div>
                <div class="bill-detail">
                    <span class="detail-label">Amount Due:</span>
                    <span class="detail-value amount">₹${bill.amountDue.toFixed(2)}</span>
                </div>
                <div class="bill-detail">
                    <span class="detail-label">Due Date:</span>
                    <span class="detail-value">${formatDate(bill.dueDate)}</span>
                </div>
                ${bill.paid && bill.paymentDate ? `
                <div class="bill-detail">
                    <span class="detail-label">Payment Date:</span>
                    <span class="detail-value">${formatDate(bill.paymentDate)}</span>
                </div>
                ` : ''}
            </div>
            ${!bill.paid ? `
                <button onclick="payBill('${bill.meterNumber}', '${bill.billingMonth}')" class="btn-pay">
                    Pay Now
                </button>
            ` : ''}
        </div>
    `).join('');
}

async function payBill(meterNumber, billingMonth) {
    try {
        const response = await fetch(`${API_BASE_URL}/${meterNumber}/pay`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ billingMonth: billingMonth })
        });
        
        if (response.ok) {
            showMessage('Payment successful!', 'success');
            showBills(currentBillType); // Refresh the current view
            updateTotalDue(); // Update total due amount
        } else {
            const errorText = await response.text();
            showMessage(errorText || 'Payment failed', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error processing payment. Please try again.', 'error');
    }
}

async function updateTotalDue() {
    if (!currentMeterNumber) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/${currentMeterNumber}/total-due`);
        const data = await response.json();
        
        const totalDueElement = document.getElementById('total-due');
        if (data.totalAmountDue > 0) {
            totalDueElement.innerHTML = `Total Amount Due: ₹${data.totalAmountDue.toFixed(2)}`;
            totalDueElement.style.display = 'block';
        } else {
            totalDueElement.style.display = 'none';
        }
    } catch (error) {
        console.error('Error updating total due:', error);
    }
}

// Admin Portal Functions
async function generateBill() {
    const meterNumber = document.getElementById('adminMeterNumber').value.trim();
    const unitsConsumed = parseInt(document.getElementById('unitsConsumed').value);
    const billingMonth = document.getElementById('billingMonth').value.trim();
    
    if (!meterNumber || !unitsConsumed || !billingMonth) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    if (unitsConsumed <= 0) {
        showMessage('Units consumed must be greater than 0', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                meterNumber: meterNumber,
                unitsConsumed: unitsConsumed,
                billingMonth: billingMonth
            })
        });
        
        if (response.ok) {
            const bill = await response.json();
            showMessage(`Bill generated successfully! Amount: ₹${bill.amountDue.toFixed(2)}`, 'success');
            
            // Clear form
            document.getElementById('adminMeterNumber').value = '';
            document.getElementById('unitsConsumed').value = '';
            document.getElementById('billingMonth').value = '';
            
            // Refresh meters list if it's displayed
            getAllMeters();
        } else {
            showMessage('Error generating bill', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error generating bill. Please try again.', 'error');
    }
}

async function getAllMeters() {
    try {
        const response = await fetch(`${API_BASE_URL}/meters`);
        const meters = await response.json();
        
        const metersList = document.getElementById('meters-list');
        
        if (meters.length === 0) {
            metersList.innerHTML = '<p>No meter numbers found</p>';
            return;
        }
        
        metersList.innerHTML = `
            <h4>Active Meter Numbers (${meters.length}):</h4>
            ${meters.map(meter => `
                <div class="meter-item" onclick="loadMeterBills('${meter}')">
                    <strong>${meter}</strong>
                    <small style="float: right; color: #6c757d;">Click to view bills</small>
                </div>
            `).join('')}
        `;
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error loading meter numbers', 'error');
    }
}

function loadMeterBills(meterNumber) {
    // Switch to customer portal and load bills
    showSection('customer');
    document.getElementById('meterNumber').value = meterNumber;
    getBills();
}

// Utility Functions
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    } catch (error) {
        return dateString;
    }
}

function showMessage(message, type) {
    const messageElement = document.getElementById('message');
    messageElement.textContent = message;
    messageElement.className = `message ${type} show`;
    
    // Auto hide after 4 seconds
    setTimeout(() => {
        messageElement.classList.remove('show');
    }, 4000);
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Set default active tab
    const firstTabBtn = document.querySelector('.tab-btn');
    if (firstTabBtn) {
        firstTabBtn.classList.add('active');
    }
    
    // Add Enter key support for meter number input
    document.getElementById('meterNumber').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            getBills();
        }
    });
    
    // Add Enter key support for admin form
    document.getElementById('billingMonth').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            generateBill();
        }
    });
    
    console.log('Electricity Billing System initialized successfully!');
});